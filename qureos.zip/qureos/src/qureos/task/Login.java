package qureos.task;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Wait;

/*==========================================
 Title:  Automated test for Login - Qureos
 Author: Rasheed PV
 Date:   20 Apr 2022
==========================================*/


public class Login {

	static WebDriver driver;
	public static void main(String[] args) 
	{
		try 
		{
		System.setProperty("webdriver.chrome.driver", "chromedriver");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
			
		driver.get("https://app.qureos.com/");
		Thread.sleep(1000);
		
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
		
		Login.Login();
	}
	
	public static void Login()
	{
		try {
		WebElement Email = driver.findElement(By.xpath("//body/div[@id='__next']/main[1]/section[1]/div[1]/section[1]/section[1]/div[1]/div[1]/form[1]/section[1]/input[1]"));
		Email.sendKeys("rcmywork@gmail.com");
		WebElement Password = driver.findElement(By.xpath("//body/div[@id='__next']/main[1]/section[1]/div[1]/section[1]/section[1]/div[1]/div[1]/form[1]/section[2]/input[1]"));
		Password.sendKeys("Ras560037KA@1");
		
		driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
		Thread.sleep(10000);
		
		WebElement VerifyLogin = driver.findElement(By.xpath("//h3[contains(text(),\"Let's get started!\")]"));
		if(VerifyLogin.isDisplayed())
		{
			System.out.println("The user is logged-In Successfully");
		}
		else
		{
			System.out.println("The user is Not logged-In");
		}
		}
		
		
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			
		}
		driver.close();
	}
	
}